package edu.brandeis.cs12b.pa10.compiler;

import java.util.*;
import edu.brandeis.cs12b.pa10.parser.ParseTreeNode;
import edu.brandeis.cs12b.vm.VMInstruction;
import edu.brandeis.cs12b.pa10.lexer.Lexeme;
import edu.brandeis.cs12b.pa10.lexer.LexemeType;
import edu.brandeis.cs12b.vm.VMOp;

public class Compiler {
	private List<ParseTreeNode> nodes;
	private Map<String, Integer> map = new HashMap<>();
	private int index = 0;
    private int mOffset = 0;
	
	public Compiler(List<ParseTreeNode> ptn) {
		nodes = ptn;
    }

    public List<VMInstruction> compile() {
        List<VMInstruction> l = new ArrayList<>();
        for (ParseTreeNode node : nodes) {
            l.addAll(getVariable(node.getLeft().getLexeme()));
            l.addAll(evalNode(node.getRight()));
            l.addAll(setVariable(node.getLeft().getLexeme()));
        }
        return l;
    }

    private List<VMInstruction> evalNode(ParseTreeNode node) {
        List<VMInstruction> l = new ArrayList<>();
        if (node.getLexeme().getType() == LexemeType.NUMBER) {
        	l.add(new VMInstruction(VMOp.SET, "r0", node.getLexeme().getValueAsString()));
        } else if (node.getLexeme().getType() == LexemeType.USER_INPUT) {
            l.add(new VMInstruction(VMOp.PROMPT, "r0"));
        } else if (node.getLexeme().getType() == LexemeType.VARIABLE) {
        	l.addAll(getVariable(node.getLexeme()));
        } else if (node.getLexeme().getType() == LexemeType.OPERATOR) {
        	int left = mOffset;
        	int right = mOffset++;
        	l.addAll(evalNode(node.getLeft()));
        	l.add(new VMInstruction(VMOp.SET, "r1", String.valueOf(left)));
            l.add(new VMInstruction(VMOp.STORE, "r1", "r0"));
            l.addAll(evalNode(node.getRight()));
            l.add(new VMInstruction(VMOp.SET, "r2", String.valueOf(right)));
            l.add(new VMInstruction(VMOp.LOAD, "r1", "r2"));
            if (node.getLexeme().getValueAsString().equals("+")) {
            	l.add(new VMInstruction(VMOp.ADD, "r0", "r1", "r0"));
            } else if (node.getLexeme().getValueAsString().equals("-")) {
            	l.add(new VMInstruction(VMOp.SUB, "r0", "r1", "r0"));
            } else if (node.getLexeme().getValueAsString().equals("*")) {
            	l.add(new VMInstruction(VMOp.MUL, "r0", "r1", "r0"));
            } else if (node.getLexeme().getValueAsString().equals("/")) {
            	l.add(new VMInstruction(VMOp.DIV, "r0", "r1", "r0"));
            } else if (node.getLexeme().getValueAsString().equals("^")) {
            	l.add(new VMInstruction(VMOp.POW, "r0", "r1", "r0"));
            }
        }
        return l;
    }

    private List<VMInstruction> getVariable(Lexeme lexeme) {
        List<VMInstruction> list = new ArrayList<>();
        if (!map.containsKey(lexeme.getValueAsString())) {
            map.put(lexeme.getValueAsString(), index);
            list.add(new VMInstruction(VMOp.SET, "r0", String.valueOf(index)));
            list.add(new VMInstruction(VMOp.OUTPUT, lexeme.getValueAsString(), "r0"));
            //increment index when there is a new variable
            index++;
        }
        int location = map.get(lexeme.getValueAsString());
        list.add(new VMInstruction(VMOp.SET, "r0", String.valueOf(location)));
        list.add(new VMInstruction(VMOp.LOAD, "r0", "r0"));
        return list;
    }

    private List<VMInstruction> setVariable(Lexeme lexeme) {
    	List<VMInstruction> list = new ArrayList<>();
    	int location = map.get(lexeme.getValueAsString());
        list.add(new VMInstruction(VMOp.SET, "r1", String.valueOf(location)));
        list.add(new VMInstruction(VMOp.STORE, "r1", "r0"));
        return list;
    }

}
