package edu.brandeis.cs12b.pa10.interpreter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import edu.brandeis.cs12b.pa10.lexer.LexemeType;
import edu.brandeis.cs12b.pa10.parser.ParseTreeNode;

public class Interpreter {
	private List<ParseTreeNode> nodes;
	private Scanner input = new Scanner(System.in);
	
	public Interpreter(List<ParseTreeNode> ptns) {
		nodes = ptns; 
	}

	public Map<String, Double> evaluate() {
		Map<String, Double> map = new HashMap<>();
		for (ParseTreeNode root : nodes) {
			ParseTreeNode var = root.getLeft();
			ParseTreeNode val = root.getRight();
			map.put(var.getLexeme().getValueAsString(), evalNode(val, map));
		}
		return map;
	}
	
	private double evalNode(ParseTreeNode node, Map<String, Double> map) {
		if (node.getLexeme().getType() == LexemeType.OPERATOR) {
			double lNode = evalNode(node.getLeft(), map);
			double rNode = evalNode(node.getRight(), map);
			if (node.getLexeme().getValueAsString().equals("+")) {
				return lNode + rNode;
			} else if (node.getLexeme().getValueAsString().equals("-")) {	
				return lNode - rNode;
			} else if (node.getLexeme().getValueAsString().equals("*")) {
				return lNode * rNode;
			} else if (node.getLexeme().getValueAsString().equals("/")) {
				return lNode / rNode;
			} else if (node.getLexeme().getValueAsString().equals("^")) {
				return Math.pow(lNode, rNode);
			}
		} else if (node.getLexeme().getType() == LexemeType.NUMBER) {
			return node.getLexeme().getValueAsNumber();
		} else if (node.getLexeme().getType() == LexemeType.USER_INPUT) {
			System.out.println("Value of " + node.getLexeme().getValueAsString() + " ? ");
			return input.nextDouble();
		} else if (node.getLexeme().getType() == LexemeType.VARIABLE) {
			return map.get(node.getLexeme().getValueAsString());
		}
		throw new Error();
	}
	
}

