package edu.brandeis.cs12b.pa10.lexer;

import java.util.Iterator;

public class Lexer implements Iterator<Lexeme> {
	private char[] ch;
    private int current = 0;

	public Lexer(String toLex) {
		ch = new char[toLex.length()];
        for (int i = 0; i < ch.length; i++) {
            ch[i] = toLex.charAt(i);
        }
	}


	@Override
	public boolean hasNext() {
		if (current == ch.length) {
			return false;
		}
        while (ch[current] == ' ' || ch[current] == '\n' || ch[current] == '\t') {
        	current++;
        }
        return !(current >= ch.length);
	}

	@Override
	public Lexeme next() {
		while (ch[current] == ' ' || ch[current] == '\n' || ch[current] == '\t') {
			current++;
		}
        char c = ch[current++];
        if (c == '(') {
        	return new Lexeme(LexemeType.LEFT_PAREN);
        } else if (c == ')') {
            return new Lexeme(LexemeType.RIGHT_PAREN);
        } else if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^') {
        	return new Lexeme(LexemeType.OPERATOR, String.valueOf(c));
        } else if (c == '=') {
        	return new Lexeme(LexemeType.EQUALS);
        } else if (c == ';') {
            return new Lexeme(LexemeType.SEMICOLON);
        } else if (c == '?') {
            return new Lexeme(LexemeType.USER_INPUT);
        // cases that the type is variable or number
        } else {
           if (Character.isAlphabetic(c)) {
        	   int start = current - 1;
               int i = start;
               while (Character.isLetter(ch[i])) {
            	   i++;
               }
               // update current when the cursor meets a variable
               current = i;
               return new Lexeme(LexemeType.VARIABLE, new String(ch, start, i - start));
           } else if (Character.isDigit(c)) {
        	   int start = current - 1;
        	   int i = start;
        	   // check if there is a point, if there is one, exit the while loop and only use the first digit
        	   // after the point
        	   boolean point = false;
        	   while (Character.isDigit(ch[i]) || (!point && ch[i] == '.')) {
        		   if (ch[i] == '.') {
        			   point = true;
        		   }
        		   // lexeme starts with . is invalid
        		   if (ch[i] == '.' && !Character.isAlphabetic(ch[i - 1])) {
        			   System.out.print("Invalid NUMBER");
        		   }
                   i++;
               }
               current = i;
               return new Lexeme(LexemeType.NUMBER, new String(ch, start, i - start));
           }
        }
        return null;
	}
	
}

