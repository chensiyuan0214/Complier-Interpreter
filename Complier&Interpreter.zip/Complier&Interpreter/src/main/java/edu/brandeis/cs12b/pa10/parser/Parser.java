package edu.brandeis.cs12b.pa10.parser;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.collections4.IteratorUtils;
import edu.brandeis.cs12b.pa10.lexer.Lexeme;
import edu.brandeis.cs12b.pa10.lexer.LexemeType;

public class Parser {
	private List<Lexeme> lex;
    private int current = 0;
    
	public Parser(Iterator<Lexeme> lexemes) {
		lex = IteratorUtils.toList(lexemes);
	}

	public List<ParseTreeNode> parse() {
        List<ParseTreeNode> l = new ArrayList<>();
        while (current < lex.size()) {
            l.add(statement());
        }
        return l;
	}
	
	private ParseTreeNode statement() {
        ParseTreeNode lNode = new ParseTreeNode(lex.get(current++));
        ParseTreeNode root = new ParseTreeNode(lex.get(current++));
        ParseTreeNode rNode = expr();
        root.setLeft(lNode);
        root.setRight(rNode);
        // pass the ;
        current++; 
        return root;
    }
	
    private ParseTreeNode expr() {
    	Lexeme l = lex.get(current++);
    	ParseTreeNode node = null;
        if (l.getType() == LexemeType.USER_INPUT || l.getType() == LexemeType.NUMBER || 
        		l.getType() == LexemeType.VARIABLE) {
        	node = new ParseTreeNode(l);
        } else if (l.getType() == LexemeType.LEFT_PAREN) {
        	node = expr();
        	current++;
        }
        if (current < lex.size() && lex.get(current).getType() == LexemeType.OPERATOR) {
            ParseTreeNode root = new ParseTreeNode(lex.get(current++));
            root.setLeft(node);
            root.setRight(expr());
            return root;
        }
        return node;
    }
    
}
