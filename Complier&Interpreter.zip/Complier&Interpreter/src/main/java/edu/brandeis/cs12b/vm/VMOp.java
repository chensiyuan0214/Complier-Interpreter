package edu.brandeis.cs12b.vm;

public enum VMOp {
	ADD, MUL, SUB, DIV, POW, STORE, LOAD, PROMPT, OUTPUT, SET;
}
